# PHỐ CỔ POS – Android project

Ứng dụng POS offline cho cửa hàng bánh mì và đồ uống. Giao diện chạy trong Android WebView; dữ liệu được lưu trên thiết bị bằng localStorage.

## Tính năng hiện có
- Bán hàng, giỏ hàng, thanh toán tiền mặt/chuyển khoản.
- Danh mục bánh mì đã nhập và mục thêm món tự điền.
- Đồ uống mẫu: Trà dưa lưới 20.000đ.
- Sản phẩm: thêm và sửa tên/giá.
- Kho nguyên liệu với bảng giá nhập và giá sỉ đã thống nhất:
  - Thịt xíu: nhập 210.000đ/kg, sỉ 220.000đ/kg
  - Jambong: nhập 100.000đ/kg, sỉ 105.000đ/kg
  - Pate: nhập 80.000đ/kg, sỉ 90.000đ/kg
  - Xúc xích: nhập 45.000đ/gói, sỉ 46.000đ/gói
- Phiếu nhập hàng, đơn bán sỉ, lịch sử và báo cáo cơ bản.
- Xuất bản sao dữ liệu JSON.

## Tạo APK bằng Android Studio
1. Cài Android Studio bản ổn định và Android SDK Platform 35.
2. Mở thư mục `pho_co_pos` bằng Android Studio (Open).
3. Chờ Gradle Sync hoàn tất.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug được tạo tại `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý quan trọng
- Đây là bản MVP offline; dữ liệu chỉ nằm trên một thiết bị, chưa đồng bộ cloud.
- Không có tài khoản nhân viên, in hóa đơn Bluetooth, máy quét mã vạch, sao lưu tự động hoặc quản lý công nợ khách hàng ở phiên bản này.
- Bán sỉ hiện áp dụng cho 4 mặt hàng nguyên liệu trong bảng giá đã chốt; nhập kho và xuất bán sỉ cập nhật số lượng tồn.
- Báo cáo doanh thu theo đơn bán lẻ; chưa tính lợi nhuận ròng hoặc chi phí vận hành.

## Tạo APK tự động bằng GitHub Actions
1. Tạo một repository GitHub mới và tải toàn bộ nội dung thư mục `pho_co_pos` lên (bao gồm thư mục `.github`).
2. Mở tab **Actions** của repository. Workflow **Build PHO CO POS APK** sẽ tự chạy khi push lên `main`/`master`; cũng có thể chọn **Run workflow**.
3. Khi chạy thành công, mở lần chạy đó và tải artifact `pho-co-pos-debug-apk` trong phần **Artifacts**.
4. Giải nén artifact để lấy `app-debug.apk`, rồi chuyển sang điện thoại Android để cài đặt. Nếu Android hỏi, cho phép cài ứng dụng từ nguồn này.

APK debug dùng để thử nghiệm/cài nội bộ; chưa phải bản phát hành ký số (release) trên Google Play.
