# PHỐ CỔ POS – Android

Ứng dụng POS offline chạy trên Android bằng WebView.

## Chức năng
- Bán hàng nhanh, giỏ hàng, thanh toán tiền mặt/chuyển khoản.
- Sẵn menu bánh mì: Trứng 16k; 2 trứng 20k; Pate trứng 20k; Pate 2 trứng 23k; Xúc xích 18k; Pate xúc xích 20k; Thập cẩm 25k; Pate dăm bông 20k.
- Thêm/sửa sản phẩm và đồ uống; quản lý tồn kho, phiếu nhập, bán sỉ.
- Báo cáo doanh thu theo ngày/tháng, tách bán lẻ/bán sỉ và phương thức thanh toán.
- Lịch sử đơn hàng, lọc theo ngày/tháng, hiển thị giờ giao dịch.
- Xuất dữ liệu JSON và khôi phục dữ liệu từ file sao lưu.
- Giao diện xanh dương sáng + đen, tối ưu điện thoại.

## Lưu trữ dữ liệu
- Dữ liệu được lưu trong bộ nhớ ứng dụng Android bằng localStorage của WebView.
- Dữ liệu KHÔNG tự reset khi sang ngày mới; báo cáo lọc theo ngày/tháng, lịch sử cũ vẫn còn.
- Dữ liệu lưu cục bộ trên máy, không tự đồng bộ cloud.
- Không gỡ ứng dụng hoặc chọn Xóa dữ liệu trong Cài đặt Android nếu muốn giữ dữ liệu.
- Nên vào Báo cáo → Xuất dữ liệu JSON để sao lưu định kỳ. Khi đổi máy/cài lại, cài app rồi chọn Khôi phục dữ liệu và chọn file backup.

## Build APK bằng GitHub Actions
1. Giải nén ZIP.
2. Đưa toàn bộ nội dung thư mục `pho_co_pos` lên thư mục gốc repository (app, .github và các file Gradle).
3. Mở Actions → Build PHO CO POS APK → Run workflow.
4. Mở run hoàn tất → Artifacts → tải `pho-co-pos-debug-apk`.
5. Giải nén artifact và cài `app-debug.apk` trên Android.

Package: `vn.phoco.pos` · JDK 17 · Gradle 8.9 · Android SDK 35.
